#ifndef TKBIO_VARSTR_H
#define TKBIO_VARSTR_H
#include <string>
#include <stdexcept>
#include <vector>
#include <map>

using std::string;
using std::vector;
using std::exception;

#include <bam.h>

#include <recrec.hxx>

using namespace tkbio;

namespace tkbio {

    typedef unsigned long long ullong;

    class bamread;
    class str_collection;
    class str_variation;

    class bamread {
    public:
        const static ullong FEATURE_MASK             = 0x3000000000000LL;
        const static ullong FEATURE_MATCH            = 0x0000000000000LL;
        const static ullong FEATURE_REPEAT_INSERTION = 0x1000000000000LL; 
        const static ullong FEATURE_REPEAT_DELETION  = 0x2000000000000LL;
        const static ullong FEATURE_ERROR            = 0x3000000000000LL;

    private:
        vector<unsigned long long> _sections;

        int _chromosome;
        int _start;
        int _stop;
    public:
        bamread(const bam1_t* read);
        int chromosome() const { 
            return _chromosome;
        }
        int position5() const { return _start; }
        int position3() const { return _stop; }
        int size() const { return _sections.size(); }
        ullong get_section(int index) const { return _sections[index]; }
        static int get_position(ullong info) { return (int)info & 0xffffffff; }
        static int get_span(ullong info) { return (int)((info >> 32) & 0xffff); }
        static char get_feature(ullong info);// { return info & FEATURE_MASK; }
        bool covers(int start, int end) const;
        bool shares_variation(ullong section) const;
        bool has_reference_at(int start, int end) const;

        string to_string() const;
        friend class strcollection;
    };

    class str_variation {
        ullong _code;
        int _num_shares;
        int _num_reference;
        int _num_others;
    public:
        str_variation();
        str_variation(ullong section_code);
        str_variation(int position, int reference_span, int read_span);
        void set_counts(int share, int reference, int others);
        int occurrence() const { return _num_shares; }
        int opposite() const { return _num_reference; }
        int coverage() const { return _num_shares + _num_reference + _num_others; }
        string to_string() const;
        ullong code() const { return _code; }
        int reference_span() const;
        int read_span() const;
        int position() const;
        char feature() const;
        friend bool operator == (const str_variation& lhs, const str_variation& rhs);
        friend class str_collection;
    };

    class str_collection {
    private:
        vector<bamread> _reads;
    public:
        str_collection();
        ~str_collection();
        void sweep(int chromosome, int start=0, int end=-1);
        void add_read(bam1_t const* read);
        int size() const { return _reads.size(); }
        vector<str_variation> get_variations(int coverage, double heterozygosity) const throw (exception);
        pair<int,int> span() const;
        int count_coverage(int start, int stop) const;
        static int detect_str(int argc, char** argv) throw (exception);
    };
}
#endif
